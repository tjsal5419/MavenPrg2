package com.newlecture.web.model.admin;

public class LectureModel {
	
}
