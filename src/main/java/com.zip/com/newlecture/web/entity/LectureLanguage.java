package com.newlecture.web.entity;

public class LectureLanguage {
	private String code;
	private String verCode;
	private String languageVerCode;
	private String lectureCode;
	private String lectureCode1;
	private String languageVerCode1;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getVerCode() {
		return verCode;
	}
	public void setVerCode(String verCode) {
		this.verCode = verCode;
	}
	public String getLanguageVerCode() {
		return languageVerCode;
	}
	public void setLanguageVerCode(String languageVerCode) {
		this.languageVerCode = languageVerCode;
	}
	public String getLectureCode() {
		return lectureCode;
	}
	public void setLectureCode(String lectureCode) {
		this.lectureCode = lectureCode;
	}
	public String getLectureCode1() {
		return lectureCode1;
	}
	public void setLectureCode1(String lectureCode1) {
		this.lectureCode1 = lectureCode1;
	}
	public String getLanguageVerCode1() {
		return languageVerCode1;
	}
	public void setLanguageVerCode1(String languageVerCode1) {
		this.languageVerCode1 = languageVerCode1;
	}

}
