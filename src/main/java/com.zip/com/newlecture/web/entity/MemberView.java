package com.newlecture.web.entity;

public class MemberView {

	
	
}
