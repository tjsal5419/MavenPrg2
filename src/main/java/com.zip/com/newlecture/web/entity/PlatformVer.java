package com.newlecture.web.entity;

public class PlatformVer {
	   private String code;
	   private String name;
	   private String platformCode;
	   
	   public String getCode() {
	      return code;
	   }
	   public void setCode(String code) {
	      this.code = code;
	   }
	   public String getName() {
	      return name;
	   }
	   public void setName(String name) {
	      this.name = name;
	   }
	   
	   public String getPlatformCode() {
	      return platformCode;
	   }
	   public void setPlatformCode(String platformCode) {
	      this.platformCode = platformCode;
	   }
	}