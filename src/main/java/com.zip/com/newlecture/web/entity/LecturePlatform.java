package com.newlecture.web.entity;

public class LecturePlatform {
	private String code;
	private String name;
	private String verCode;
	private String ver;
	private String lectureCode;
	private String platformVerCode;
	private String lectureCode1;
	private String platformVerCode1;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVerCode() {
		return verCode;
	}
	public void setVerCode(String verCode) {
		this.verCode = verCode;
	}
	public String getVer() {
		return ver;
	}
	public void setVer(String ver) {
		this.ver = ver;
	}
	public String getLectureCode() {
		return lectureCode;
	}
	public void setLectureCode(String lectureCode) {
		this.lectureCode = lectureCode;
	}
	public String getPlatformVerCode() {
		return platformVerCode;
	}
	public void setPlatformVerCode(String platformVerCode) {
		this.platformVerCode = platformVerCode;
	}
	public String getLectureCode1() {
		return lectureCode1;
	}
	public void setLectureCode1(String lectureCode1) {
		this.lectureCode1 = lectureCode1;
	}
	public String getPlatformVerCode1() {
		return platformVerCode1;
	}
	public void setPlatformVerCode1(String platformVerCode1) {
		this.platformVerCode1 = platformVerCode1;
	}
	
}
